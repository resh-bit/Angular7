import { MustMatchDirective } from './mustmatch.directive';

describe('MustmatchDirective', () => {
  it('should create an instance', () => {
    const directive = new MustMatchDirective();
    expect(directive).toBeTruthy();
  });
});
